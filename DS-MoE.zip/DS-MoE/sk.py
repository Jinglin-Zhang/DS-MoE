import torch
from torch import nn
from transformers import AutoTokenizer, AutoModel
import torch.nn.functional as F

class DeepSeekMoEEncoder(nn.Module):
    def __init__(self, num_experts=4, expert_dim=256):
        super().__init__()
        # 初始化DeepSeek模型
        self.model = AutoModel.from_pretrained('/home/datasets/deepseekmoe/deepseek-moe-16b-base',trust_remote_code=True,)
        self.tokenizer = AutoTokenizer.from_pretrained('/home/datasets/deepseekmoe/deepseek-moe-16b-base',trust_remote_code=True,)

        # MoE参数
        self.num_experts = num_experts
        self.expert_dim = expert_dim

        # 专家网络
        self.experts = nn.ModuleList([
            nn.Sequential(
                nn.Linear(self.model.config.hidden_size, expert_dim),
                nn.GELU(),
                nn.Linear(expert_dim, expert_dim)
            ) for _ in range(num_experts)
        ])

        # 门控网络
        self.gate = nn.Linear(self.model.config.hidden_size, num_experts)

        # 冻结基础模型参数
        for param in self.model.parameters():
            param.requires_grad = False

    def forward(self, texts):
        inputs = self.tokenizer(texts, return_tensors='pt', padding=True)
        outputs = self.model(**inputs)
        pooled = outputs.last_hidden_state[:, 0]  # 取[CLS] token

        # MoE处理
        gate_scores = F.softmax(self.gate(pooled), dim=1)
        expert_outputs = []
        for i in range(self.num_experts):
            expert_out = self.experts[i](pooled)
            expert_outputs.append(gate_scores[:, i].unsqueeze(1) * expert_out)

        # 合并专家输出
        moe_output = torch.sum(torch.stack(expert_outputs), dim=0)
        return moe_output


def test_moe_encoder():
    # 初始化编码器（使用CPU测试）
    encoder = DeepSeekMoEEncoder(num_experts=4)

    # 测试输入
    defect_labels = [
        "surface crack",
        "metal corrosion",
        "paint scratch",
        "weld defect"
    ]

    # 执行编码
    with torch.no_grad():
        embeddings = encoder(defect_labels)

    # 验证输出
    assert embeddings.shape == (4, 256), f"输出维度错误，实际维度：{embeddings.shape}"
    print("测试通过！输出示例：")
    print(f"第一个标签的嵌入向量：\n{embeddings[0][:5]}...")  # 显示前5个维度


if __name__ == "__main__":
    test_moe_encoder()