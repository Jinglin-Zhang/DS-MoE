# Copyright (c) OpenMMLab. All rights reserved.
import argparse
import os
from typing import Sequence
from sklearn.manifold import TSNE
# import mmcv
from mmdet.apis import inference_detector, init_detector
from mmengine import Config, DictAction
from mmengine.registry import init_default_scope
from mmengine.utils import ProgressBar
import torch
# from mmyolo.registry import VISUALIZERS
from mmyolo.utils.misc import auto_arrange_images, get_file_list
import numpy as np
# import altair as alt
# import pandas as pd
import torch.nn.functional as F
import matplotlib.pyplot as plt
from pycocotools.coco import COCO
import os.path as osp

def parse_args():
    #/home/server/zzk_wp/mmyolo/configs/yolov8/v8_sam_ps.py
    #/home/server/zzk_wp/mmyolo/tools/test/best_coco_bbox_mAP_epoch_500.pth
    # / home / server / zzk_wp / mmyolo / tools / al_v8 / epoch_500.pth
    parser = argparse.ArgumentParser(description='Visualize t-sne')
    parser.add_argument(
        '--img',default='/home/server/datasets/ZZK/al/images/', help='Image path, include image file, dir and URL.')
    parser.add_argument('--config',default='/home/server/zzk_wp/mmyolo/configs/yolov8/yolov8_l_syncbn_fast_8xb16-500e_coco.py', help='Config file')
    parser.add_argument('--checkpoint',default='/home/server/zzk_wp/mmyolo/tools/v8_l_al_1/best_coco_bbox_mAP_epoch_118.pth', help='Checkpoint file')
    parser.add_argument(
        '--out-dir', default='./output', help='Path to output file')
    parser.add_argument(
        '--target-layers',
        default=['neck'],
        nargs='+',
        type=str,
        help='The target layers to get feature map, if not set, the tool will '
        'specify the backbone')
    parser.add_argument(
        '--preview-model',
        default=False,
        action='store_true',
        help='To preview all the model layers')
    parser.add_argument(
        '--device', default='cuda:0', help='Device used for inference')
    parser.add_argument(
        '--score-thr', type=float, default=0.3, help='Bbox score threshold')
    parser.add_argument(
        '--show', default=True, help='Show the featmap results')
    parser.add_argument(
        '--cfg-options',
        nargs='+',
        action=DictAction,
        help='override some settings in the used config, the key-value pair '
        'in xxx=yyy format will be merged into config file. If the value to '
        'be overwritten is a list, it should be like key="[a,b]" or key=a,b '
        'It also allows nested list/tuple values, e.g. key="[(a,b),(c,d)]" '
        'Note that the quotation marks are necessary and that no white space '
        'is allowed.')
    args = parser.parse_args()
    return args


class ActivationsWrapper:

    def __init__(self, model, target_layers):
        self.model = model
        self.activations = []
        self.handles = []
        self.image = None
        for target_layer in target_layers:
            self.handles.append(
                target_layer.register_forward_hook(self.save_activation))

    def save_activation(self, module, input, output):
        self.activations.append(output)

    def __call__(self, img_path):
        self.activations = []
        results = inference_detector(self.model, img_path)
        return results, self.activations

    def release(self):
        for handle in self.handles:
            handle.remove()


def main():

    args = parse_args()

    cfg = Config.fromfile(args.config)
    if args.cfg_options is not None:
        cfg.merge_from_dict(args.cfg_options)

    init_default_scope(cfg.get('default_scope', 'mmyolo'))


    model = init_detector(args.config, args.checkpoint, device=args.device)

    if not os.path.exists(args.out_dir) and not args.show:
        os.mkdir(args.out_dir)

    if args.preview_model:
        print(model)
        print('\n This flag is only show model, if you want to continue, '
              'please remove `--preview-model` to get the feature map.')
        return

    target_layers = []
    for target_layer in args.target_layers:
        try:
            target_layers.append(eval(f'model.{target_layer}'))
        except Exception as e:
            print(model)
            raise RuntimeError('layer does not exist', e)

    activations_wrapper = ActivationsWrapper(model, target_layers)





    # init visualizer
    # visualizer = VISUALIZERS.build(model.cfg.visualizer)
    # visualizer.dataset_meta = model.dataset_meta

    # get file list
    image_list, source_type = get_file_list(args.img)

    progress_bar = ProgressBar(len(image_list))
    # feature_bank = []
    # label_bank = []
    for j,image_path in enumerate(image_list):
        result, featmaps = activations_wrapper(image_path)
        if not isinstance(featmaps, Sequence):
            featmaps = [featmaps]

        flatten_featmaps = []
        for featmap in featmaps:
            if isinstance(featmap, Sequence):
                flatten_featmaps.extend(featmap)
            else:
                flatten_featmaps.append(featmap)

        # img = mmcv.imread(image_path)
        # img = mmcv.imconvert(img, 'bgr', 'rgb')

        if source_type['is_dir']:
            filename = os.path.relpath(image_path, args.img).replace('/', '_')
        else:
            filename = os.path.basename(image_path)
        out_file = None if args.show else os.path.join(args.out_dir, filename)

        # show the results
        shown_imgs = []
        # bbox=result.pred_instances
        # bbox=result.
        pred_instances = result.pred_instances
        pred_instances = pred_instances[
        pred_instances.scores > 0.3]
        # pred_instances.bboxes=pred_instances.bboxes/result.batch_input_shape[0]
        # print(flatten_featmaps[1].shape[3])
        # for label in pred_instances.labels:
        #     label_bank.append(label.to('cpu'))
        for i, bbox in enumerate(pred_instances.bboxes):

            bbox[0] = torch.ceil(bbox[0] / result.ori_shape[0] * flatten_featmaps[0].shape[2]).int()
            bbox[2] = torch.ceil(bbox[2] / result.ori_shape[0] * flatten_featmaps[0].shape[2]).int()
            bbox[1] = torch.ceil(bbox[1] / result.ori_shape[1] * flatten_featmaps[0].shape[3]).int()
            bbox[3] = torch.ceil(bbox[3] / result.ori_shape[1] * flatten_featmaps[0].shape[3]).int()
            cutting_feature=flatten_featmaps[0][:,:,bbox[0].int():bbox[2].int(), bbox[1].int():bbox[3].int()]
            if cutting_feature.shape[0]==0 or cutting_feature.shape[1]==0 or cutting_feature.shape[2]==0 or cutting_feature.shape[3]==0:
                continue
            label=pred_instances.labels[i]
            label = label.unsqueeze(0)
            # label_bank.append(label)
            #.to('cpu').numpy()

            cutting_feature= F.interpolate(cutting_feature, size=(flatten_featmaps[0].shape[2], flatten_featmaps[0].shape[3]), mode='bilinear', align_corners=True)
            # feature_bank.append(cutting_feature)
            #numpy()
            if 'features' in locals():
                features = torch.cat((features, cutting_feature))
                labels = torch.cat((labels, label))

            else:
                features = cutting_feature
                labels = label
        progress_bar.update()

    # for i,feature in enumerate(feature_bank):
    #     if i == 0 :
    #         features = feature
    #     else:
    #         features = torch.cat((features,feature))
    # for i,label in enumerate(label_bank):
    #     label=label.unsqueeze(0)
    #     if i == 0 :
    #         labels = label
    #     else:
    #         labels = torch.cat((labels,label))
    bn=torch.nn.BatchNorm2d(256)
    bn.to('cuda:0')
    features= bn(features)
    features = features.mean(dim=(2, 3))
    # features=features[:50, :, :, :]
    # labels = labels[:50,:]
    # features = np.array(feature_bank)
    # labels = np.array(label_bank)
    # tsne = TSNE(n_components=2, random_state=0).fit_transform(X=features)


    # # 提取 x 和 y 坐标
    # k = 5000  # 否则会报错：MaxRowsError: The number of rows in your dataset is greater than the maximum allowed (5000).
    # label = labels[:k]
    # x = tsne[:k, 0]
    # y = tsne[:k:, 1]
    #
    # # 创建 DataFrame
    # df = pd.DataFrame({'x': x, 'y': y, 'label': label})
    #
    # # 创建散点图
    # chart = alt.Chart(df).mark_point(filled=True).encode(x="x", y="y", color="label:N").properties(width=400,
    #                                                                                                height=400)
    # chart = chart.configure_axis(
    #     disable=True,  # 禁用坐标轴
    # )
    # chart
    # for box in true_boxes:
    #     x, y, width, height, class_id = box
    #     class_features.append(feature_map[y:y + height, x:x + width])

    # model.eval()
    # with torch.no_grad():
    #     for i, (image_batch, label_batch) in enumerate(testloader):
    #         image_batch, label_batch = image_batch.cuda(), label_batch.cuda()
    #         label_batch = label_batch.long().squeeze()
    #         inputs = image_batch
    #         logits, feature = model(inputs)
    #         if i == 0:
    #             feature_bank = feature
    #             label_bank = label_batch
    #         else:
    #             feature_bank = torch.cat((feature_bank, feature))
    #             label_bank = torch.cat((label_bank, label_batch))
    #
    feature_bank = features.detach().cpu().numpy()
    label_bank = labels.cpu().numpy()
    # p, pseu = torch.max(torch.softmax(logits_bank, dim=-1), dim=-1)
    # prob_bank = p.cpu().numpy()
    tsne = TSNE(2,perplexity=55)
    output = tsne.fit_transform(feature_bank)  # feature进行降维，降维至2维表示
    # 带真实值类别
    colors = ['purple', 'green', 'blue', 'orange']

    for i in range(4):  # 对每类的数据画上特定颜色的点
        index = (label_bank == i)
        plt.scatter(output[index, 0], output[index, 1], s=4, color=colors[i])
    classes = ('Pinhole', 'Scratch', 'Dirty','Fold')
    plt.legend(classes,fontsize='large')
    plt.show()
    plt.savefig('figure.png', dpi=300)


if __name__ == '__main__':
    main()
