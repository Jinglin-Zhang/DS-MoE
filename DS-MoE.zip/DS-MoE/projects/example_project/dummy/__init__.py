# Copyright (c) OpenMMLab. All rights reserved.
from .dummy_yolov5cspdarknet import DummyYOLOv5CSPDarknet

__all__ = ['DummyYOLOv5CSPDarknet']
