# 15 minutes to get started with MMYOLO rotated object detection

TODO
