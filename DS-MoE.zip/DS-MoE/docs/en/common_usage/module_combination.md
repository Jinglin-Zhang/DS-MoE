# Module combination
